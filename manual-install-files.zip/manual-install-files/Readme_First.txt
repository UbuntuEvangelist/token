TokenLite - ICO / STO Token Sale Management Dashboard @by Softnio.
--------------------------------------------------------------------------

All the files are in this folder are related for manual install and it not require for Nio Laravel Installer.

#######################################################
####   IF you go through Default / Manual Install  ####
#######################################################

> First update the '.env' file from 'tokenlite_app' folder according to your information. 
  APP_NAME, APP_URL, DB_HOST, DB_DATABASE, DB_USERNAME, DB_PASSWORD 

> You will need to copy the 'installed' file and placed into 'tokenlite_app/storage' folder.

> Import the 'dummy_app.sql' into your database for demo data. 

> Once above complete, please go to your website url and setup your Super Admin account. 


--------------------------------------------------------------------------
|
|  .htaccess 
|  
|  - this file may require you if face problem  
|    to open website for 'mod_rewrite' rules. 
|
|  ^ Caution: It's already in /public folder but sometimes
|    you may need if you update PHP version for install application. 
|
--------------------------------------------------------------------------

Thanks for choose our products.
Softnio Team.